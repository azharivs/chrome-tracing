'use strict';

class Popup {
  constructor() {
    // Communication with backgound.
    this.port_ = chrome.runtime.connect();

    // Controls.
    this.uploadLink_ = document.getElementById('run');
    this.uploadLink_.addEventListener('click', this.onRun.bind(this));
    this.uploadLink_ = document.getElementById('stop');
    this.uploadLink_.addEventListener('click', this.onStop.bind(this));

    // Settings.
    this.pagecycle_active_ = document.getElementById('pagecycle_active');
    this.pagecycle_active_.checked =
        Boolean(localStorage.getItem('pagecycle_active'));
    this.pagecycle_active_.addEventListener(
        'change', this.onPageCycleActiveChange.bind(this));
  }

  onRun() {
    this.port_.postMessage('start');
  }

  onStop() {
    this.port_.postMessage('stop');
  }

  onPageCycleActiveChange() {
    if (this.pagecycle_active_.checked) {
      localStorage.setItem('pagecycle_active', 1);
    } else {
      localStorage.removeItem('pagecycle_active');
    }
  }
}

let popup = undefined;
window.addEventListener('load', function() {
  popup = popup || new Popup();
});
