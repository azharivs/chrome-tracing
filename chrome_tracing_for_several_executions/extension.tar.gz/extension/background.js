// Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

'use strict';

function getRandomArbitrary(min, max) {
  return Math.floor(Math.random() * (max - min)) + min;
}

function getRandomElementFrom(elements) {
  let position = getRandomArbitrary(0, elements.length);
  return elements[position];
}


function IdleTabAction(tab) {
  // Do nothing.
}

function ReloadTabAction(tab) {
 chrome.tabs.reload(tab.id, ()=> {
    if (chrome.runtime.lastError) {
      console.log(chrome.runtime.lastError.message);
    }
  });
}

function HighlightTabAction(tab) {
 chrome.tabs.highlight(tab.id, ()=> {
    if (chrome.runtime.lastError) {
      console.log(chrome.runtime.lastError.message);
    }
  });
}

function ZoomTabAction(tab) {
 chrome.tabs.setZoom(tab.id, 0.5, ()=> {
    if (chrome.runtime.lastError) {
      console.log(chrome.runtime.lastError.message);
    }
  });
}

function UnzoomTabAction(tab) {
 chrome.tabs.setZoom(tab.id, 1., ()=> {
    if (chrome.runtime.lastError) {
      console.log(chrome.runtime.lastError.message);
    }
  });
}

class PageCycleTest {
  static get TICK_MS() { return 3000; }
  static get ACTION_BY_TAB() { return 10; }
  static get MAX_ACTIVE_TABS() { return 4; }

  constructor() {
    this.state_ = "idle";
    this.sites_ = [];
    this.sites_loaded_ = false;
    this.paused = false
    this.active_tabs_count_ = 0;
    this.active_tabs_ = new Set();

    this.tab_actions_ = [
      IdleTabAction,
      ReloadTabAction,
      ZoomTabAction,
      UnzoomTabAction
      //HighlightTabAction
    ];
  }

  LoadSites() {
    var request = new XMLHttpRequest();
     request.overrideMimeType("application/json");
     request.open("GET", "alexa.json", true);
     request.onreadystatechange = (()=> {
       if (request.readyState === 4 && request.status == "200") {
         this.sites_ = JSON.parse(request.responseText);
         this.sites_loaded_ = true;
       }
    }).bind(this);
    request.send();
  }

  Start() {
    if (this.state_ !== "idle")
      return;

    this.state_ = "running";

    this.tick_timer_ =
      setInterval(this.onTick.bind(this),
                  PageCycleTest.TICK_MS);
  }

  Stop() {
    if (this.state_ !== "running")
      return;
    clearInterval(this.tick_timer_);
    this.state_ = "idle";

    // Clearing tabs.;
    for (let tab of this.active_tabs_)
      chrome.tabs.remove(tab.tab.id);

    this.active_tabs_count_ = 0;
    this.active_tabs_ = new Set();
  }

  Pause() { this.paused_ = true; }
  Resume() { this.paused_ = false; }

  onTick() {
    if (!this.sites_loaded_ || this.paused || this.state_ === "idle")
      return;
    const views = chrome.extension.getViews({type: 'popup'});
    if (views.length != 0)
      return;
    if (this.state_ === "running")
      this.RunningState();
  }

  RunningState() {
    // Open a tab.
    if (this.active_tabs_count_ < PageCycleTest.MAX_ACTIVE_TABS) {
      this.active_tabs_count_++;
      let url = getRandomElementFrom(this.sites_);
      chrome.tabs.create({url: url}, ((tab)=> {
        if (chrome.runtime.lastError) {
          this.active_tabs_count_--;
          console.log(chrome.runtime.lastError.message);
        } else {
          let new_tab = {
            tab: tab,
            state: "open",
            remaining_actions: PageCycleTest.ACTION_BY_TAB
          };
          this.active_tabs_.add(new_tab);
        }
      }).bind(this));
    }

    // Perform an action.
    for (let tab of this.active_tabs_) {
      if (tab.remaining_actions != 0) {
        let tab_action = getRandomElementFrom(this.tab_actions_);
        tab_action(tab);
        tab.remaining_actions--;
      }
    }

    // Closing tabs.
    for (let tab of this.active_tabs_) {
      if (tab.remaining_actions == 0) {
        tab.state = "closing";
        chrome.tabs.remove(tab.tab.id, ()=> {
          if (chrome.runtime.lastError)
            console.log(chrome.runtime.lastError.message);
        });
      }
    }

    // Cleanup dead tabs.
    chrome.tabs.query({}, ((tabs)=> {
      for (let tab of this.active_tabs_) {
        let found = false;
        for (let i = 0; i < tabs.length; ++i) {
          if (tabs[i].id === tab.tab.id) {
            found = true;
            break;
          }
        }
        if (!found) {
          this.active_tabs_count_--;
          this.active_tabs_.delete(tab);
        }
      }
    }).bind(this));

  }

};

const test = new PageCycleTest();
test.LoadSites();

chrome.runtime.onConnect.addListener((port)=> {
  test.Pause();

  port.onMessage.addListener((msg)=> {
    switch (msg) {
    case 'start':
      test.Start();
      break;
    case 'stop':
      test.Stop();
      break;
    }
  });

  port.onDisconnect.addListener(()=> {
    test.Resume();
  });

})
